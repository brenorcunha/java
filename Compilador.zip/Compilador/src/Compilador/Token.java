package Compilador;
public enum Token {
    // nome das constantes das linhas 19 a 26 que identifica os tipos de token
    NOME_VARIAVEL, INT, DEC, COMENTARIO, BRANCO, PALAVRA_CHAVE, ERROR;
    
}
