class Hash {
  public double item;
  public boolean ocupado;
  
  public Hash(boolean b) { // construtor
    ocupado = b;
  }
}