import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Scanner menu = new Scanner (System.in);
        while (true) {
            System.out.print("##--Digite a opcao desejada:--##\n\n");
            System.out.print("|--------------------------------------|\n");
            System.out.print("| Opção 1 - Busca de palavra reservada:|\n");
            System.out.print("| Opção 2 - Leitura de TXT:            |\n");
            System.out.print("| Opção 3 - Sair                       |\n");
            System.out.print("|--------------------------------------|\n");

            int opcao = menu.nextInt();

            if (opcao == 3) {
                System.out.print("\nAté logo!");
                menu.close(); 
            }

            switch (opcao) {
            case 1:
                System.out.print("\nDigite a palavra desejada: ");
                break;

            case 2:
                System.out.println("\nInforme o arquivo de texto: ");
                String texto = menu.nextLine();
                System.out.println("\n Conteudo do arquivo: ");
                try {
                    FileReader arq = new FileReader(texto);
                    BufferedReader lerArq = new BufferedReader(arq);
                    String linha = lerArq.readLine(); // lê a primeira linha
                    // a variável "linha" recebe o valor "null" quando o processo
                        // de repetição atingir o final do arquivo texto
                    while (linha != null) {
                        System.out.printf("%s\n", linha);
                        linha = lerArq.readLine(); // lê da segunda até a última linha
                    }
                    arq.close();
                } catch (IOException e) {
                    System.err.printf("Erro na abertura do arquivo: %s.\n",
                    e.getMessage());
                }
                System.out.println();
            default:
                System.out.print("\nOpção Inválida!");
                break;
        }
    }

 }
}
