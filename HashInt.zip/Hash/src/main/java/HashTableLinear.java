import java.util.*; // pacote contem System.in

class HashTableLinear {
    public static void main(String[] args) {
      HashLinear tab = new HashLinear(7);
      Scanner le = new Scanner(System.in);
      int item;
  
      System.out.println("\n*********************************************************************");
      System.out.println("Tabela HASH com tratamento de colisoes Linear (7 itens reais - double)");
      System.out.print("*********************************************************************");
      for (int i=0; i<7; i++){
      System.out.print("\n\nInserindo elemento " + (i+1) );
      System.out.print(" - Forneca valor inteiro: ");
      item = le.nextInt();
      tab.insere(item);
      }
  
      System.out.print("\n\nBuscando campo\n>>> Forneca o item: ");
      item = le.nextInt();
      if ( tab.busca(item) != -1 )
         System.out.print("Item encontrado na posicao " + tab.busca(item));
      else
         System.out.print("Item nao encontrado");
      
      System.out.print("\n\nApagando campo\n>>> Forneca o item: ");
      item = le.nextInt();
      tab.apaga(item);
      
      System.out.print("\n\nImprimindo conteudo");
      tab.imprime();
  
      System.out.println("\n");
      le.close();
    }
  }